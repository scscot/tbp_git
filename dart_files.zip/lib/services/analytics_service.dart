class AnalyticsService {
  void logEvent(String name, Map<String, dynamic> params) {
    // Placeholder: integrate with real analytics later
    print('Analytics event: \$name, data: \$params');
  }
}
