class ChatService {
  Future<void> sendMessage(String userId, String message) async {
    // Placeholder for chat logic
    print('Sending message from \$userId: \$message');
  }
}
